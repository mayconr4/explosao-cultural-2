<?php 
namespace ExplosaoCultural\Enums; 

enum TipoClassificacao:string{ 
    case INFANTIL = 'Infantil';  
    case  ADULTO = 'adulto'; 

   
}     