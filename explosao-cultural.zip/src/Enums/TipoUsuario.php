<?php

namespace ExplosaoCultural\Enums; 


enum TipoUsuario:string{
    case ADMINISTRADOR = 'Administrador';
    case USUARIO = 'Usuario';
    
    

} 

