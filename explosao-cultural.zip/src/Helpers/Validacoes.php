<?php
namespace ExplosaoCultural\Helpers;

use ExplosaoCultural\Enums\TipoUsuario;
use InvalidArgumentException;

final class Validacoes
{
    private function __construct() {}

    public static function validarNome(string $nome): void
    {
        if (empty($nome)) {
            throw new InvalidArgumentException("Nome não pode ser vazio.");
        }
    } 

    public static function validarDataNascimento(string $dataNascimento): void
    {
        if (empty($dataNascimento)) {
            throw new InvalidArgumentException("Data de nascimento não pode ser vazia.");
        }

        $data = \DateTime::createFromFormat('Y-m-d', $dataNascimento);
        if (!$data || $data->format('Y-m-d') !== $dataNascimento) {
            throw new InvalidArgumentException("Data de nascimento inválida.");
        }
    }

    public static function validarEmail(string $email): void
    {
        if (empty($email)) {
            throw new InvalidArgumentException("Email não pode ser vazio.");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Email inválido.");
        }
    }

    public static function validarSenha(string $senha): void
    {
        if (empty($senha)) {
            throw new InvalidArgumentException("Senha não pode ser vazia.");
        }
    }

    public static function validarTipo(string $tipo): void
    {
        if (empty($tipo)) {
            throw new InvalidArgumentException("Selecione um tipo de usuário.");
        }

        if (!TipoUsuario::tryFrom($tipo)) {
            throw new InvalidArgumentException("Tipo de usuário inválido.");
        }
    }




    public static function validarTitulo(string $titulo): void
    {
        if (empty($titulo)) {
            throw new InvalidArgumentException("Título não pode ser vazio.");
        }
    }

    public static function validarDescricao(string $texto): void
    {
        if (empty($texto)) {
            throw new InvalidArgumentException("Texto não pode ser vazio.");
        }
    } 

    public static function validarResumo(string $resumo): void
    {
        if (empty($resumo)) {
            throw new InvalidArgumentException("Resumo não pode ser vazio.");
        }

        if (mb_strlen($resumo) > 300) {
            throw new InvalidArgumentException("Resumo deve ter no máximo 300 caracteres.");
        }
    }

   
    public static function validarGenero(int $generoId): void
    {
        if (empty($generoId) || $generoId <= 0) {
            throw new InvalidArgumentException("Selecione um gênero válido.");
        }
    }
}